# -*- coding: utf-8 -*-
"""
    ResolveURL Plugin - LuluStream (2025 - Headers completos + bypass)
"""

from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


class LuluStreamResolver(ResolveUrl):
    name = 'LuluStream'
    domains = [
        'lulustream.com', 'luluvdo.com', 'lulu.st', 'luluvid.com',
        '732eg54de642sa.sbs', 'cdn1.site', 'streamhihi.com',
        'luluvdoo.com', 'd00ds.site', 'llvid.com', 'luluflix.com'
    ]
    pattern = r'(?://|\.)((?:lulu(?:stream|vdo|vid|flix)?|732eg54de642sa|cdn1|streamhihi|d00ds|llvid)\.(?:com|sbs|site))/(?:e/|d/|v/)?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)

        headers = {
            'User-Agent': common.RAND_UA,
            'Referer': web_url,
            'Origin': f'https://{host}',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin'
        }

        html = self.net.http_GET(web_url, headers=headers).content

        # Padrão principal
        match = re.search(r'''sources:\s*\[{[^}]*file:\s*["']([^"']+)["']''', html)
        if not match:
            # Padrão alternativo (alguns domínios mudaram)
            match = re.search(r'''file:\s*["']([^"']+\.m3u8[^"']*)["']''', html)
        if not match:
            raise ResolverError('LuluStream: Stream não encontrado')

        stream_url = match.group(1)

        # Headers finais para o stream (crucial para bypass)
        stream_headers = {
            'User-Agent': common.RAND_UA,
            'Referer': web_url,
            'Origin': f'https://{host}',
            'Accept': '*/*',
            'Sec-Fetch-Mode': 'no-cors'
        }

        return stream_url + helpers.append_headers(stream_headers)

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')